export class Forgetpasswordclass {
    custId: String;
  emailId: string;
  firstname: string;
  lastname: String;
  address: String;
  phoneNo: string;
  password: String;
}
