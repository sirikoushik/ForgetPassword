import { Component, OnInit } from '@angular/core';
import { FpasswordService } from '../forgetpassword.service';
import { Router } from '@angular/router';
import { Forgetpasswordclass } from '../forgetpasswordclass';

@Component({
  selector: 'app-password',
  templateUrl: './password.component.html',
  styleUrls: ['./password.component.css']
})
export class PasswordComponent implements OnInit {
  pass = new Forgetpasswordclass();
  constructor(private router: Router, private fpass:FpasswordService) { }

  ngOnInit() {
  }
  cpass(pass1: string,pass2: string)
  {
    if(pass1 === pass2){
      this.fpass.cpass(pass1, pass2).subscribe(data => {
       
      })
       window.alert('Password changed Successfully');
    }
   else{
    window.alert('Password is not matched');
   }
  }

  }

