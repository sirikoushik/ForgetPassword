import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { FpasswordService } from '../forgetpassword.service';
import { Forgetpasswordclass } from '../forgetpasswordclass';

@Component({
  selector: 'app-forget',
  templateUrl: './forget.component.html',
  styleUrls: ['./forget.component.css']
})
export class ForgetComponent implements OnInit {
  pass = new Forgetpasswordclass();
  constructor(private router: Router, private fpass:FpasswordService) { }
  

  falgVal : string;
  ngOnInit() {
  }
  login(email,name,phno)
  {
    this.pass.emailId=email;
    this.pass.firstname=name;
    this.pass.phoneNo=phno;
    this.fpass.login(email,name,phno).subscribe(data=>{
      this.falgVal=data;
      if(data === "Please enter valid Details")
      {
        window.alert('Invalid credentials.');
      }
      else{
        this.fpass.setId(data);
        alert(this.fpass.getId())
        this.router.navigate(['/password']);
      }
      
      },error=>{alert("Incorrect Account Number")});
  }

}
