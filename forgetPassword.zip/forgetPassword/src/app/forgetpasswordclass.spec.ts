import { Forgetpasswordclass } from './forgetpasswordclass';

describe('Forgetpasswordclass', () => {
  it('should create an instance', () => {
    expect(new Forgetpasswordclass()).toBeTruthy();
  });
});
