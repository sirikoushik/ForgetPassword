import { TestBed } from '@angular/core/testing';

import { FpasswordService } from './forgetpassword.service';

describe('FpasswordService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: FpasswordService = TestBed.get(FpasswordService);
    expect(service).toBeTruthy();
  });
});
