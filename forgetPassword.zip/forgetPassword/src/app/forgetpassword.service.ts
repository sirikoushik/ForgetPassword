import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class FpasswordService {
  em: string;
  constructor(private httpClient:HttpClient) { }
  login(mail,fname,phno):Observable<string>
  {
    
  let url = 'http://localhost:2209/login/'+mail+'/'+fname+'/'+phno;
  
  return this.httpClient.get<string>(url);
  }
  cpass(pass1,pass2):Observable<string>
  {
  let url = 'http://localhost:2209/pass/'+this.em+'/'+pass1+'/'+pass2;
  console.log(url);
  return this.httpClient.put<string>(url,"");
  }

  getId(){
    return this.em;
    }
    
    setId(id:string){
      this.em = id;
    }
}
