import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PasswordComponent } from './password/password.component';
import { ForgetComponent } from './forget/forget.component';

const routes: Routes = [
  {path : 'forget',component:ForgetComponent},
  {path : 'password',component:PasswordComponent},
  { path:'',redirectTo:'forget', pathMatch:'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
