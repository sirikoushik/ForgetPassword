package com.capstore.exception;

public class CustomException extends Exception {
CustomException(){
		
	}
	public CustomException(String msg)
	{
		super(msg);
	}
}
