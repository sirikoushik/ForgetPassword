package com.capstore.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.bean.Credential;
import com.capstore.bean.Customer;

import com.capstore.dao.CredentialDao;
import com.capstore.dao.CustomerDao;

import com.capstore.exception.CustomException;

@Service
public class CapgService {

	//	@Autowired CustomerDao customerRepo;
	//	@Autowired WishItemDao customerWishRepo;
	//	public void registerCustomer(Customer customer) {
	//		customerRepo.save(customer);
	//	}
	//	
	//	public Customer findCustomerById(String custId) {  
	//		return customerRepo.findById(custId).get();
	//	}
	//	public void addCustomerWish(String custId,WishItem wish) {
	//		Customer customer = findCustomerById(custId);
	//		List<WishItem> wishList = customer.getWishItems();
	//		wishList.add(wish);
	//		customer.setWishItems(wishList);
	//		customerWishRepo.save(wish);
	//		customerRepo.save(customer);
	//	}

	@Autowired
	CustomerDao custDao;
	@Autowired
	CredentialDao credDao;
	Customer obj;


	public String login(String email, String fname, String phno) throws CustomException {

		try{
			Customer customer = custDao.getCustomerByMail(email);
			System.out.println(custDao.findAll());
	
			if(customer.getEmailId().equals(email) && customer.getFirstName().equals(fname) && customer.getPhoneNo().equals(phno) )
			{

			
				return customer.getCustId();
			}
			else
			{
				return "Please enter valid Details";
			}
		}
		catch(Exception ex)
		{
			throw new CustomException("Please enter valid Details");
		}



	}

	public String changePassword(String id,String pass1, String pass2) throws CustomException {
		try {
			Credential obj1=credDao.getCustomerById(id);
			if(pass1.equals(pass2))
			{
				obj1.setPassword(pass1);
				credDao.save(obj1);
				return "Password matched";
			}
			else
			{
				return "Passwords does not match";
			}
		}
		catch(Exception ex)
		{
			throw new CustomException("Please enter valid Details");
		}

	}
}
