package com.capstore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.PutMapping;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.exception.CustomException;
import com.capstore.service.CapgService;



@RestController
@CrossOrigin(origins="http://localhost:4200")
public class CapgController {

//	@Autowired CapgService capgService;
//	
//	@PostMapping("/register")
//	public void registerCustomer(@RequestBody Customer customer) {
//		capgService.registerCustomer(customer);
//	}
//	@PostMapping("/addWish/{custId}")
//	public void addCustomerWish(@PathVariable String custId,@RequestBody WishItem wish) {
//		capgService.addCustomerWish(custId,wish);
//	}
	
	@Autowired CapgService capgService;

   
      @RequestMapping(value = "/login/{email}/{fname}/{phno}")
    	public String login(@PathVariable String email,@PathVariable String fname,@PathVariable String phno) throws CustomException {
    		return capgService.login(email, fname,phno);
    	}
      
      @PutMapping("/pass/{id}/{pass1}/{pass2}")
  	public String changePassword(@PathVariable String id,@PathVariable String pass1,@PathVariable String pass2) throws CustomException {
  		
  		return capgService.changePassword(id,pass1,pass2);
  	}	
}
