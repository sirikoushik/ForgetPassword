package com.capstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capstore.bean.CartItem;

public interface CartItemDao extends JpaRepository<CartItem, String> {

}
