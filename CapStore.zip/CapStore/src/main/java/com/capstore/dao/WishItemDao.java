package com.capstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capstore.bean.WishItem;

public interface WishItemDao extends JpaRepository<WishItem, String>{

}
