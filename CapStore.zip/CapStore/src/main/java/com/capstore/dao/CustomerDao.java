package com.capstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capstore.bean.Customer;

@Repository
public interface CustomerDao extends JpaRepository<Customer, String>{

	@Query("from Customer where emailId=:mail")
 	public Customer getCustomerByMail(@Param("mail") String mail);
	
}
