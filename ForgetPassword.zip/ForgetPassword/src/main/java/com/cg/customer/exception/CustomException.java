package com.cg.customer.exception;

public class CustomException extends Exception
{
	CustomException(){
		
	}
	public CustomException(String msg)
	{
		super(msg);
	}
}
