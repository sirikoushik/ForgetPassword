package com.cg.customer.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


import com.cg.customer.bean.Customer;

@Repository
public interface CustomerDao  extends JpaRepository<Customer,Integer>{
	@Query("select p from Customer p where p.mailId=:mail")
 	Customer getCustomerByMail(@Param("mail") String mailId);
	
	

}
