package com.cg.customer.service;

import com.cg.customer.bean.Customer;
import com.cg.customer.exception.CustomException;

public interface CustomerService {

	String login(String email, String fname, String phno) throws CustomException;

	String changePassword(String email,String pass1, String pass2) throws CustomException;

}
