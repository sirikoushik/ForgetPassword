package com.cg.customer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;

import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;


import com.cg.customer.exception.CustomException;
import com.cg.customer.service.CustomerService;


@CrossOrigin(origins="http://localhost:4200")
@RestController
public class CustomController
{
	
		@Autowired
		CustomerService service;
	
	   
	      @RequestMapping(value = "/login/{email}/{fname}/{phno}")
	    	public String login(@PathVariable String email,@PathVariable String fname,@PathVariable String phno) throws CustomException {
	    		return service.login(email, fname,phno);
	    	}
	      
	      @PutMapping("/pass/{id}/{pass1}/{pass2}")
	  	public String changePassword(@PathVariable String email,@PathVariable String pass1,@PathVariable String pass2) throws CustomException {
	  		
	  		return service.changePassword(email,pass1,pass2);
	  	}

}
