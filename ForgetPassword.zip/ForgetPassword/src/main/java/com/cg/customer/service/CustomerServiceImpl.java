package com.cg.customer.service;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.cg.customer.bean.Credential;
import com.cg.customer.bean.Customer;
import com.cg.customer.dao.CredentialDao;
import com.cg.customer.dao.CustomerDao;
import com.cg.customer.exception.CustomException;



@Service
public class CustomerServiceImpl implements CustomerService {
	@Autowired
	CustomerDao custDao;
	@Autowired
	CredentialDao credDao;
	Customer obj;

	@Override
	public String login(String email, String fname, String phno) throws CustomException {
		
		try{
			obj =custDao.getCustomerByMail(email);
			if(obj.getEmailId().equals(email)&& obj.getFirstName().equals(fname) && obj.getPhoneNo().equals(phno) )
			{
				
	return obj.getCustId();
		}
			else
			{
				return "Please enter valid Details";
			}
		}
		catch(Exception ex)
		{
			throw new CustomException("Please enter valid Details");
		}
	
	
	
	}
	@Override
	public String changePassword(String id,String pass1, String pass2) throws CustomException {
		try {
			Credential obj1=credDao.getCustomerById(id);
		
		if(pass1.equals(pass2))
		{
			obj1.setPassword(pass1);
			
			
			credDao.save(obj1);
			return "Password matched";
		}
		else
		{
			return "Passwords does not match";
		}
		}
		catch(Exception ex)
		{
			throw new CustomException("Please enter valid Details");
		}
		
	}

}

