package com.cg.customer.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.customer.bean.Credential;


@Repository
public interface CredentialDao  extends JpaRepository<Credential,Integer>{
	@Query("select p from Credential p where p.id=:id")
 	Credential getCustomerById(@Param("id") String id);



}
